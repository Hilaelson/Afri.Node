import { Router } from "express";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { config } from "../config.js";
import { requireAuth } from "../middleware/auth.js";
import { sendWelcomeEmail } from "../services/mailer.js";

const router = Router();

// "Banco" em memória só para demo
const users = new Map(); // email -> { email, passwordHash, createdAt }

function signToken(user) {
  return jwt.sign({ sub: user.email }, config.jwtSecret, { expiresIn: "7d" });
}

router.post("/register", async (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email e password obrigatórios" });
  if (users.has(email)) return res.status(409).json({ error: "email já registado" });

  const passwordHash = await bcrypt.hash(password, 10);
  const user = { email, passwordHash, createdAt: new Date().toISOString() };
  users.set(email, user);

  try { await sendWelcomeEmail(email); } catch (e) { console.warn("email falhou:", e.message); }

  const token = signToken(user);
  res.status(201).json({ token, user: { email, createdAt: user.createdAt } });
});

router.post("/login", async (req, res) => {
  const { email, password } = req.body || {};
  const user = users.get(email);
  if (!user) return res.status(401).json({ error: "credenciais inválidas" });
  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) return res.status(401).json({ error: "credenciais inválidas" });
  const token = signToken(user);
  res.json({ token, user: { email, createdAt: user.createdAt } });
});

router.get("/me", requireAuth, (req, res) => {
  const email = req.user?.sub;
  const user = users.get(email);
  if (!user) return res.status(404).json({ error: "usuário não encontrado" });
  res.json({ email: user.email, createdAt: user.createdAt });
});

export default router;